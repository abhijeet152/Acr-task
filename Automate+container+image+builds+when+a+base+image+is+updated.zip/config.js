const backgroundColor = '{BACKGROUND_COLOR}';
document.documentElement.style.setProperty('--bg-color', backgroundColor);
